<?php
/**
 * Plugin Name: WooCommerce Categories Display Manager
 * Description: A plugin to hide specific product categories from the WooCommerce shop page, search results, and archives.
 * Version: 1.1
 * Author: Kenneth Kiprotich
 * Author URI: https://osayworld.com
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Create settings page
function wc_categories_display_manager_menu() {
    add_options_page(
        'WooCommerce Categories Display Manager', // Page title
        'Categories Display Manager', // Menu title
        'manage_options', // Capability
        'wc-categories-display-manager', // Menu slug
        'wc_categories_display_manager_settings_page' // Function to display the page
    );
}
add_action( 'admin_menu', 'wc_categories_display_manager_menu' );

// Display settings page
function wc_categories_display_manager_settings_page() {
    ?>
    <div class="wrap">
        <h1>WooCommerce Categories Display Manager</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields( 'wc_categories_display_manager_group' );
                do_settings_sections( 'wc-categories-display-manager' );
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
function wc_categories_display_manager_settings_init() {
    register_setting( 'wc_categories_display_manager_group', 'wc_hidden_categories' );
    register_setting( 'wc_categories_display_manager_group', 'wc_hide_in_search' );
    register_setting( 'wc_categories_display_manager_group', 'wc_hide_in_archives' );

    add_settings_section(
        'wc_categories_display_manager_section',
        'Select Categories to Hide',
        null,
        'wc-categories-display-manager'
    );

    // Categories field
    add_settings_field(
        'wc_hidden_categories',
        'Hidden Categories',
        'wc_hidden_categories_callback',
        'wc-categories-display-manager',
        'wc_categories_display_manager_section'
    );

    // Hide in Search field
    add_settings_field(
        'wc_hide_in_search',
        'Hide in Search Results',
        'wc_hide_in_search_callback',
        'wc-categories-display-manager',
        'wc_categories_display_manager_section'
    );

    // Hide in Archives field
    add_settings_field(
        'wc_hide_in_archives',
        'Hide in Archives',
        'wc_hide_in_archives_callback',
        'wc-categories-display-manager',
        'wc_categories_display_manager_section'
    );
}
add_action( 'admin_init', 'wc_categories_display_manager_settings_init' );

// Callback for hidden categories
function wc_hidden_categories_callback() {
    $categories = get_terms( 'product_cat', array( 'hide_empty' => false ) );
    $hidden_categories = get_option( 'wc_hidden_categories', array() );
    
    foreach ( $categories as $category ) {
        $checked = in_array( $category->term_id, $hidden_categories ) ? 'checked' : '';
        echo '<label><input type="checkbox" name="wc_hidden_categories[]" value="' . $category->term_id . '" ' . $checked . ' /> ' . $category->name . '</label><br>';
    }
}

// Callback for hide in search
function wc_hide_in_search_callback() {
    $hide_in_search = get_option( 'wc_hide_in_search', false );
    $checked = $hide_in_search ? 'checked' : '';
    echo '<input type="checkbox" name="wc_hide_in_search" value="1" ' . $checked . ' /> Hide selected categories in search results';
}

// Callback for hide in archives
function wc_hide_in_archives_callback() {
    $hide_in_archives = get_option( 'wc_hide_in_archives', false );
    $checked = $hide_in_archives ? 'checked' : '';
    echo '<input type="checkbox" name="wc_hide_in_archives" value="1" ' . $checked . ' /> Hide selected categories in archives';
}

// Modify WooCommerce query to hide selected categories
function wc_hide_categories_from_shop_page( $query ) {
    if ( ! is_admin() && $query->is_main_query() ) {
        $hidden_categories = get_option( 'wc_hidden_categories', array() );

        // Exclude categories from shop page
        if ( is_shop() && ! empty( $hidden_categories ) ) {
            $tax_query = (array) $query->get( 'tax_query' );
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'id',
                'terms'    => $hidden_categories,
                'operator' => 'NOT IN',
            );
            $query->set( 'tax_query', $tax_query );
        }

        // Exclude categories from search results
        if ( is_search() && get_option( 'wc_hide_in_search', false ) ) {
            $tax_query = (array) $query->get( 'tax_query' );
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'id',
                'terms'    => $hidden_categories,
                'operator' => 'NOT IN',
            );
            $query->set( 'tax_query', $tax_query );
        }

        // Exclude categories from archives
        if ( is_archive() && get_option( 'wc_hide_in_archives', false ) ) {
            $tax_query = (array) $query->get( 'tax_query' );
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'id',
                'terms'    => $hidden_categories,
                'operator' => 'NOT IN',
            );
            $query->set( 'tax_query', $tax_query );
        }
    }
}
add_action( 'pre_get_posts', 'wc_hide_categories_from_shop_page' );
