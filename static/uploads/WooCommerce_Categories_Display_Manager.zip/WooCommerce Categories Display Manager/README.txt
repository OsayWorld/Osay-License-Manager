=== WooCommerce Categories Display Manager ===
Contributors: Kenneth
Tags: woocommerce, categories, hide, search, archives, display
Requires at least: 5.0
Tested up to: 6.0
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WooCommerce Categories Display Manager allows you to manage product category visibility on your WooCommerce store. Hide categories from the shop page, search results, and archive pages with ease.

== Description ==

**WooCommerce Categories Display Manager** is a simple yet powerful plugin that gives you control over the display of your WooCommerce store’s product categories. You can easily hide specific categories from the shop page, search results, and archive pages without affecting their visibility on other parts of your store.

**Key Features:**
* Select categories to hide from the WooCommerce shop page.
* Hide categories from search results with a checkbox option.
* Hide categories from archive pages.
* Intuitive settings interface in the WordPress dashboard.
* Category visibility can be managed without affecting direct access via URL.

**How It Works:**
1. After activating the plugin, navigate to **Settings > Categories Display Manager**.
2. Select the product categories you want to hide.
3. Check the additional options to hide categories from search results and archives if needed.
4. Save your settings and the selected categories will be hidden from the specified areas of your store.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/woocommerce-categories-display-manager/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to **Settings > Categories Display Manager** to configure the categories you want to hide from the shop page, search results, and archive pages.

== Frequently Asked Questions ==

= Will hidden categories still be accessible through direct URLs? =

Yes, even if a category is hidden from the shop, search, or archive pages, it can still be accessed through a direct URL.

= Can I hide multiple categories at once? =

Yes, you can select multiple categories to hide by checking the relevant checkboxes on the settings page.

= Does this plugin remove categories completely from the site? =

No, the plugin hides categories from selected areas (shop, search, archives). Categories and their products remain accessible through direct URLs and other parts of the WooCommerce store.

== Screenshots ==

1. **Admin Settings Page** - Select the categories to hide from the shop, search, and archive pages.
2. **Shop Page Before** - Example of categories visible on the shop page.
3. **Shop Page After** - Example of hidden categories after configuration.

== Changelog ==

= 1.0 =
* Initial release of the plugin.

== Upgrade Notice ==

= 1.0 =
First version of the plugin. No upgrades yet.

== License ==
This plugin is licensed under the GPLv2 or later.
