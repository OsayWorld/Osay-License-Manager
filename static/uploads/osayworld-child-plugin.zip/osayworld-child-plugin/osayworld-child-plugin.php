<?php
/*
Plugin Name: Osayworld Child Plugin
Description: A child plugin that verifies the user is registered to use the Osayworld Plugin Manager.
Version: 1.0
Author: Osayworld
*/

// Hook to check if the user is registered with the Osayworld Plugin Manager
add_action('admin_init', 'osayworld_child_check_registration');

// Function to check registration with the Osayworld Plugin Manager
function osayworld_child_check_registration() {
    if (!osayworld_is_user_registered()) {
        add_action('admin_notices', 'osayworld_registration_failed_notice');
        deactivate_plugins(plugin_basename(__FILE__)); // Deactivate the child plugin if registration fails
    }
}

// Function to display a notice if registration check fails
function osayworld_registration_failed_notice() {
    echo '<div class="notice notice-error"><p>Osayworld Plugin Manager Registration failed. Please ensure you are registered to use this plugin.</p></div>';
}

// Function to check if the user is registered with the Osayworld Plugin Manager
function osayworld_is_user_registered() {
    // Replace with the API URL for checking user registration
    $api_url = 'https://your-license-api.com/verify-user';

    // Replace with the user-specific key stored in the database (or add a field to the plugin settings)
    $user_license_key = get_option('osayworld_user_license_key', '');

    if (empty($user_license_key)) {
        return false; // No license key, registration check fails
    }

    // Make the API request to verify user registration
    $response = wp_remote_post($api_url, [
        'body' => [
            'license_key' => $user_license_key,
        ],
    ]);

    if (is_wp_error($response)) {
        return false; // API request failed
    }

    // Decode the response from the API
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body);

    // Check the API response for registration status
    if (isset($data->status) && $data->status == 'registered') {
        return true; // User is registered
    }

    return false; // User is not registered
}

// Add settings for the user to enter their license key
add_action('admin_menu', 'osayworld_child_plugin_menu');
function osayworld_child_plugin_menu() {
    add_options_page(
        'Osayworld Child Plugin Settings',
        'Osayworld Child Settings',
        'manage_options',
        'osayworld-child-plugin-settings',
        'osayworld_child_plugin_settings_page'
    );
}

// Display the settings page for the plugin
function osayworld_child_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>Osayworld Child Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('osayworld_child_plugin_settings');
            do_settings_sections('osayworld_child_plugin_settings');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">License Key</th>
                    <td><input type="text" name="osayworld_user_license_key" value="<?php echo esc_attr(get_option('osayworld_user_license_key')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register the settings for the license key
add_action('admin_init', 'osayworld_child_plugin_settings_init');
function osayworld_child_plugin_settings_init() {
    register_setting('osayworld_child_plugin_settings', 'osayworld_user_license_key');
}
?>
